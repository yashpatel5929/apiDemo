package com.example.apicalldemo.Model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class GetMovieDetail {

    @SerializedName("title")
    private String title;

    @SerializedName("status")
    private String status;


}
